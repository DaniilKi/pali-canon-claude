"""Independent raw-source metadata review, not application/test execution."""
from pathlib import Path
import collections,gzip,hashlib,json,re,xml.etree.ElementTree as ET
E=Path('/tmp/pali-next-ten-evidence-nov26');A=E/'acceptance-plan/schema-adapter-v1';S=E/'source-oracle';F=Path('/tmp/pali-boundaries340-nov26');O=E/'browser-independent-review'
H=lambda b:hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()
J=lambda v:H(json.dumps(v,ensure_ascii=False,separators=(',',':')))
T=lambda v:json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def eq(a,b,code):
 if T(a)!=T(b):raise ValueError(code)
def physical(p):
 p=Path(p)
 if not p.is_absolute() or not p.is_file() or any(z.is_symlink() for z in [p,*p.parents]):raise ValueError('nonphysical regular source')
 return p.read_bytes()
def read(p):return json.loads(physical(p))
seal=read(S/'FINAL_ORACLE_SEAL.json')
if H(physical(S/'FINAL_ORACLE_SEAL.json'))!='fb1e29730c4208ea866ab23cd1eb35d5c85d1658a33037933be756bfdef841d9':raise ValueError('source seal')
for n,d in seal['files'].items():
 raw=physical(S/n)
 if len(raw)!=d['bytes'] or H(raw)!=d['sha256']:raise ValueError('sealed source artifact drift')
a=read(S/'FUTURE_ORACLE.json');observed=read(S/'ISOLATED_RENDER_POSITIONS.json');reader=read(A/'READER_ORACLES.json');cross=read(A/'CROSSWALK144.json');sx=read(S/'POSITION_CROSSWALK144.json')
m=read(F/'server/data/canon.json.gz.parts.json');pieces=[]
for d in m['parts']:
 b=physical(F/'server/data'/d['file'])
 if len(b)!=d['size'] or H(b)!=d['sha256']:raise ValueError('frozen DD part')
 pieces.append(b)
packed=b''.join(pieces)
if len(packed)!=m['size'] or H(packed)!=m['sha256']:raise ValueError('frozen packed')
raw=gzip.decompress(packed)
if H(raw)!=a['old_canonical_logical_sha256']:raise ValueError('frozen logical')
canon=json.loads(raw);books=canon['books'];sourceproof={};xmlnodes={}
def collapse(s):return re.sub(r'\s+',' ',s).strip()
def visible(n):
 chunks=[n.text or '']
 for child in n:
  if child.tag not in ('note','pb') and not(child.tag=='hi' and child.get('rend') in ('paranum','dot')):chunks.append(visible(child))
  chunks.append(child.tail or '')
 return ''.join(chunks)
for bi in (36,37):
 d=a['original_sources'][str(bi)];blob=physical(d['path'])
 if len(blob)!=d['bytes'] or H(blob)!=d['sha256'] or hashlib.sha1(b'blob '+str(len(blob)).encode()+b'\0'+blob).hexdigest()!=d['git_blob_sha1']:raise ValueError('original XML identity')
 nodes=[n for n in ET.fromstring(blob).iter() if n.tag in ('p','head','trailer')];tuples=[];omitted=[];retained=[]
 for i,n in enumerate(nodes):
  text=collapse(visible(n));number=n.get('n')
  if not text and not number:omitted.append(i);continue
  pages={}
  for p in n.iter('pb'):pages.setdefault(p.get('ed'),[]).append('.'.join(str(int(x)) for x in p.get('n').split('.')))
  tuples.append([n.get('rend') or ('centre' if n.tag=='trailer' else 'bodytext'),number,text,[collapse(''.join(v.itertext())) for v in n.iter('note')],pages]);retained.append(n)
 eq(tuples,books[bi]['blocks'],'all raw tuples differ');eq(omitted,d['omitted_note_only_indices'],'omissions differ')
 if len(tuples)!=d['retained_tuples'] or J(tuples)!=d['full_tuple_sha256']:raise ValueError('all tuple hash')
 xmlnodes[bi]=retained;sourceproof[str(bi)]={'path':d['path'],'sha256':H(blob),'full_tuple_sha256':J(tuples),'tuples':len(tuples),'omitted_note_only_indices':omitted}
# Independent finite grouping from original tuples; no producer or application code imported.
VERSE={'gatha1','gatha2','gatha3','gathalast'};HEAD={'subhead','title','chapter','book','nikaya','subsubhead'};CENTER=re.compile(r'(niṭṭhit[aāo]ṃ?|niṭṭhitā|samattaṃ|samattā)\.?$|^Namo tassa|uddānaṃ$',re.I)
ED={'T':('thai','Thai'),'M':('myanmar','Myanmar'),'V':('vri','VRI')}
def unique(v):return list(dict.fromkeys(v))
def render(u):
 book=books[u['book']];rows=book['blocks'];groups=[];active=None;carry=[]
 def flush():
  nonlocal active
  if active is not None:groups.append(active);active=None
 for i in range(u['start'],u['end']):
  rend,num,text,notes,pages=rows[i];events=carry+[(ed,p) for ed in ED for p in pages.get(ed,[])];carry=[]
  if rend=='hangnum':flush();active={'type':'verse','number':num,'parts':[],'notes':[],'pts':[],'ed':events,'start':i,'end':i+1};continue
  if rend in VERSE:
   if active is None:active={'type':'verse','number':num,'parts':[],'notes':[],'pts':[],'ed':[],'start':i,'end':i+1}
   active['parts'].append(text);active['notes'].extend(notes);active['pts'].extend(pages.get('P',[]));active['ed'].extend(events);active['end']=i+1
   if rend=='gathalast':flush()
  else:
   flush()
   if not text:carry=events;continue
   groups.append({'type':'heading' if rend in HEAD or rend=='centre' and CENTER.search(text) else 'prose','number':num,'parts':[text],'notes':notes,'pts':pages.get('P',[]),'ed':events,'start':i,'end':i+1})
 flush();answer=[]
 def pts(p):
  v,at=map(int,p.split('.'));return {'ap':'Ap','mn':'M'}[u['collection']]+' '+(({1:'i',2:'ii',3:'iii'}.get(v,str(v))+' ') if v else '')+str(at)
 def edition(ed,p):
  v,at=map(int,p.split('.'));return ED[ed][1]+' '+{'ap':'Ap','mn':'MN'}[u['collection']]+' '+(str(v)+'.' if v else '')+str(at)
 for offset,g in enumerate(groups):
  text=''
  for p in g['parts']:text+=('\n' if text else '')+p
  answer.append({'ref':u['id']+'/'+str(offset+1),'uid':u['id'],'segment_index0':offset,'offset':offset,'type':g['type'],'vri_paragraph':g['number'],'source_blocks':[g['start'],g['end']],'text_sha256':H(text),'text_utf16_length':len(text.encode('utf-16-le'))//2,'source_note_sha256':[H(z) for z in g['notes']],'source_notes_sha256':J(g['notes']),'variant_reading_count':len(g['notes']),'raw_PTS_page_begins':unique(g['pts']),'raw_edition_page_begins':{ed:unique([p for e,p in g['ed'] if ed==e]) for ed in ED},'pts_page_begins':unique([pts(p) for p in g['pts']]),**{ED[ed][0]+'_page_begins':unique([edition(ed,p) for e,p in g['ed'] if ed==e]) for ed in ED}})
 return answer
records={r['id']:r for r in a['records']};old={};new={};shape=[]
for unit,oldraw,newraw in zip(reader['units'],observed['old'],observed['proposed'],strict=True):
 uid=unit['id'];record=records[uid];eq(unit['before_unit'],record['before'],'before full object');eq(unit['after_unit'],record['after'],'after full object')
 oldmodel=render(record['before']);newmodel=render(record['after']);eq(unit['old_segments'],oldmodel,'old full source metadata');eq(unit['future_segments'],newmodel,'future full source metadata')
 for rows,orig in [(oldmodel,oldraw),(newmodel,newraw)]:
  for z,w in zip(rows,orig['segments'],strict=True):
   for k,v in w.items():eq(z[{'notes_sha256':'source_notes_sha256','note_count':'variant_reading_count','note_text_sha256':'source_note_sha256'}.get(k,k)],v,'sealed source alias')
 old.update({z['ref']:z for z in oldmodel});new.update({z['ref']:z for z in newmodel});shape.append({'id':uid,'old':len(oldmodel),'future':len(newmodel)})
for row,source in zip(cross['records'],sx['records'],strict=True):
 eq(row['old'],old[row['old']['ref']],'cross old');eq(row['source_identical_future_owner'],new[row['source_identical_future_owner']['ref']],'cross future');eq(row['same_numeric_ref_future'],new.get(row['old']['ref']),'cross collision')
 eq(row['old']['source_blocks'],row['source_identical_future_owner']['source_blocks'],'cross physical span');eq(row['category'],source['classification'],'cross class')
 if row['automatic_private_data_migration_authorized'] is not False or row['require_new_pin_for_old_position'] is not True:raise ValueError('migration policy')
rawbookmodels={};anchor_metadata=[]
for bi in (36,37):
 book=books[bi];bid=book['file'].replace('.mul.xml','');model=render({'id':'vri-book:'+bid,'book':bi,'start':0,'end':len(book['blocks']),'collection':book['collection']});rawbookmodels[bi]=model
 eq(reader['source_book_totals'][str(bi)],{'book':bid,'segments':len(model),'whole_metadata_sha256':J(model)},'whole raw-book identity')
for page in reader['source_book_pages']:
 bi=page['source_book_index'];rows=rawbookmodels[bi];args=page['arguments'];offset=args['offset'];wanted=rows[offset:offset+args['limit']];eq(page['segments'],wanted,'anchor page independent rendering')
 focus=page['source_block_focus'];hit=[i for i,r in enumerate(rows) if r['source_blocks'][0]<=focus<r['source_blocks'][1]];eq(hit,[page['focus_segment_offset']],'anchor physical focus');eq(rows[hit[0]]['ref'],page['focus_segment_ref'],'anchor actual ref');eq(offset,max(0,hit[0]-1),'anchor preceding source segment');anchor_metadata.append({'book':bi,'focus':focus,'offset':offset})
byid={u['id']:u for u in canon['units']};VRI='2d134ff9ef60f70a1eb03c9370580228811a3070'
for ctrl in reader['unaffected_controls']:
 u=byid[ctrl['arguments']['uid']];eq(ctrl['record_sha256'],J(u),'control full record');eq(ctrl['segments'],render(u)[:1],'control source metadata');eq(ctrl['locator_revision'],VRI+'-'+u['index_revision'] if 'index_revision' in u else None,'control prior pin')
eq(reader['all61_book_hash'],a['preservation']['all61_books_sha256'],'61 book authority');eq(reader['all61_book_hash'],J(books),'61 physical book tuples');eq(reader['other8534_unit_hash'],J([u for u in canon['units'] if u['id'] not in records]),'8534 ordered metadata');eq(reader['unchanged_apadana_manifest_sha256'],H(physical(F/'server/data/apadana.json')),'343 English manifest')
# Original inline event proof: no source text is written or logged.
n=xmlnodes[36][10788];prefix=[''];events=[]
def walk(n):
 prefix[0]+=n.text or ''
 for child in n:
  if child.tag=='pb':
   text=collapse(prefix[0]);events.append({'edition':child.get('ed'),'page':'.'.join(str(int(v)) for v in child.get('n').split('.')),'visible_offset':len(text),'visible_prefix_sha256':H(text)})
  elif child.tag!='note' and not(child.tag=='hi' and child.get('rend') in ('paranum','dot')):walk(child)
  prefix[0]+=child.tail or ''
walk(n);eq(events,a['notes_and_pages']['PTS10788_inline'],'inline source markers')
receipt={'schema':'independent-next10-source-adapter-peer-review-v1','status':'GO_EXACT_SOURCE_METADATA_ADAPTER_ONLY_NOT_RUNTIME_RELEASE','reviewer':'/root/next_ten_browser_review','source_only_standalone_review_script':{'path':str(Path(__file__).resolve()),'sha256':H(physical(Path(__file__).resolve()))},'source_seal_sha256':H(physical(S/'FINAL_ORACLE_SEAL.json')),'source_oracle_sha256':H(physical(S/'FUTURE_ORACLE.json')),'adapter_seal_sha256':H(physical(A/'ADAPTER_SEAL_FINAL.json')),'reader_oracles':{'path':str(A/'READER_ORACLES.json'),'sha256':H(physical(A/'READER_ORACLES.json'))},'crosswalk':{'path':str(A/'CROSSWALK144.json'),'sha256':H(physical(A/'CROSSWALK144.json'))},'frozen_canonical_logical_sha256':H(raw),'full288_rendered_metadata_rows_independently_equal_raw_source_model':True,'all288_sealed_original_render_aliases_equal':True,'old_future_unique_positions':[len(old),len(new)],'source_note_occurrences':[sum(z['variant_reading_count'] for z in d.values()) for d in (old,new)],'units':shape,'crosswalk_partitions':dict(collections.Counter(z['category'] for z in cross['records'])),'source_books':sourceproof,'raw_book_metadata_totals':{str(bi):{'segments':len(z),'sha256':J(z)} for bi,z in rawbookmodels.items()},'all16_rawbook_anchor_positions_pages_and_surrounding_segments_independently_equal':len(anchor_metadata)==16,'all17_prior_and_neighbor_control_objects_and_pins_equal_frozen':len(reader['unaffected_controls'])==17,'preservation':{'all61_book_tuples':reader['all61_book_hash'],'other8534_ordered_records':reader['other8534_unit_hash'],'343English_manifest':reader['unchanged_apadana_manifest_sha256'],'old_private_migration_authorized':False},'PTS10788_inline':events,'PTS290_is_carried_start_not_inline291':True,'source_words_or_notes_written':False,'candidate_application_output_used_as_expectation':False,'application_modules_or_producer_imported_or_run':False,'application_tests_browser_build_Git_CI_network_executed':False,'execution_classification':'Independent stdlib-only raw-source/JSON metadata reconstruction and comparisons; no application or repository test execution.','scope_limits':['This closes the missing source-model/schema adapter peer role for these exact hashes only.','No actual installed/public browser behavior, signed-in host, physical device, human assistive test, provider uptime, final Git test commit, CI or promotion acceptance.']}
out=O/'SOURCE_ADAPTER_PEER_REVIEW.json'
with out.open('x') as stream:stream.write(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':H(physical(out)),'status':receipt['status'],'rows':receipt['old_future_unique_positions'],'notes':receipt['source_note_occurrences']}))
