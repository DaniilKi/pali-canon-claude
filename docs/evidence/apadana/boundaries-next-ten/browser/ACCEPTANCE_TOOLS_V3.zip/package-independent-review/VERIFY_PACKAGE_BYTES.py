"""Read-only archive/Git/checkout/installation comparison; no app imports."""
import base64
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import subprocess
import tarfile

R=Path('/tmp/pali-next-ten-boundaries-nov26')
E=Path('/tmp/pali-next-ten-evidence-nov26')
O=E/'package-independent-review'
APP='6ab4a322108aec740c330e4afd974ee4da808886'
INV_SHA='ea2b5cfb7c7a6c9216e2f33a5d1950c128b1ef50cb6c32cf929cf555b942408f'
REVIEW_SHA='b3197bdcc429700dee09446abd01ff08c6009d4fcaedc3f2f542429c4f497f55'
INSTALLED=E/'installed/node_modules/pali-canon-mcp'
ARCHIVE=E/'package/pali-canon-mcp-2.1.0.tgz'
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(b):return {'bytes':len(b),'sha256':sha(b)}
def read(p):return Path(p).read_bytes()
def j(p):return json.loads(read(p))
def dump(name,value):
    path=O/name
    with path.open('x') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return {'path':str(path),'sha256':sha(read(path))}
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='',GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GIT_TERMINAL_PROMPT='0')
def git_blob(path):
    return subprocess.run(['git','--no-pager','show',APP+':'+path],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,check=True).stdout
def physical(root,name):
    assert root.is_dir() and not root.is_symlink()
    node=root
    for i,part in enumerate(PurePosixPath(name).parts):
        node=node/part
        assert not node.is_symlink(),str(node)
        assert node.is_file() if i==len(PurePosixPath(name).parts)-1 else node.is_dir(),str(node)
    return read(node)
pack=j(E/'package/pack.json')
assert len(pack)==1
pack=pack[0]
assert pack['name']=='pali-canon-mcp' and pack['version']=='2.1.0' and pack['filename']==ARCHIVE.name
raw=read(ARCHIVE)
archive_sha=sha(raw)
assert len(raw)==pack['size'] and hashlib.sha1(raw).hexdigest()==pack['shasum']
assert 'sha512-'+base64.b64encode(hashlib.sha512(raw).digest()).decode()==pack['integrity']
assert pack['entryCount']==len(pack['files'])==39
declared={row['path']:row['size'] for row in pack['files']}
assert len(declared)==39
members={}
with tarfile.open(ARCHIVE,'r:gz') as archive:
    entries=archive.getmembers()
    assert len(entries)==39
    for member in entries:
        assert member.isfile() and member.name.startswith('package/')
        name=member.name.removeprefix('package/')
        p=PurePosixPath(name)
        assert name==p.as_posix() and not p.is_absolute() and all(x not in ('','.','..') for x in p.parts)
        assert name in declared and name not in members
        data=archive.extractfile(member).read()
        assert len(data)==member.size==declared[name]
        assert data==physical(R,name)==git_blob(name)==physical(INSTALLED,name),name
        members[name]=rec(data)
members=dict(sorted(members.items()))
assert sum(row['bytes'] for row in members.values())==pack['unpackedSize']
installed_names=[]
for p in INSTALLED.rglob('*'):
    assert not p.is_symlink(),str(p)
    if p.is_file():installed_names.append(p.relative_to(INSTALLED).as_posix())
    else:assert p.is_dir()
assert sorted(installed_names)==list(members)
runtime={name.removeprefix('server/'):row for name,row in members.items() if name.startswith('server/')}
assert len(runtime)==34
invpath=E/'runtime-inventory/INDEPENDENT_NEXT_TEN_RUNTIME_INVENTORY.json'
reviewpath=E/'runtime-review/INDEPENDENT_NEXT_TEN_RUNTIME_REVIEW.json'
assert sha(read(invpath))==INV_SHA and sha(read(reviewpath))==REVIEW_SHA
inv,review=j(invpath),j(reviewpath)
assert runtime==inv['files']==review['files'] and inv['candidate_commit']==review['candidate_commit']==APP
assert review['status']=='APPROVE_EXACT_CURRENT34_RUNTIME_INVENTORY_SOURCE_SCOPE_ONLY'
O.mkdir(exist_ok=True)
common={'candidate_commit':APP,'archive':str(ARCHIVE),'archive_sha256':archive_sha,'installed':str(INSTALLED),'members':members,'runtime_inventory':{'path':str(invpath),'sha256':INV_SHA},'runtime_review':{'path':str(reviewpath),'sha256':REVIEW_SHA},'behavioral_harness_approval':False,'release_or_push_approval':False}
final={'schema':'independent-next-ten-git-archive-installed39-binding-v1','status':'PASS','commit':APP,'all39_commit_archive_installed_exact':True,**common,'verification_scope':'Read-only archive39, Git exact application commit39, current checkout39 and genuine installed39 byte equality; not install command/browser/application behavior.'}
byte_review={'schema':'independent-next-ten-install39-byte-review-v1','status':'PASS_BYTES_ONLY_INSTALL_PROCESS_EVIDENCE_PENDING','all39_archive_checkout_install_bytes_exact':True,**common,'archive_sha1':pack['shasum'],'archive_integrity':pack['integrity'],'archive_bytes':len(raw),'unpacked_bytes':pack['unpackedSize'],'pack_json':{'path':str(E/'package/pack.json'),'sha256':sha(read(E/'package/pack.json'))},'symlinks_or_archive_nonregular_members':0,'pending':['Exact root-owned offline install command and debug/network evidence; do not infer lifecycle/network flags from added1package log.', 'Separately source-derived whole WIDGET_HTML bytes and source export/reconstruction evidence.'],'app_test_browser_build_network_execution_by_reviewer':False}
runtime_doc={'schema':'independent-next-ten-installed-runtime34-binding-v1','status':'PASS_INVENTORY_ONLY','candidate_commit':APP,'files':runtime,'source_inventory':common['runtime_inventory'],'source_review':common['runtime_review'],'archive_sha256':archive_sha,'behavioral_harness_approval':False,'release_or_push_approval':False}
descriptors={'final_commit_binding':dump('FINAL_COMMIT_ARCHIVE_INSTALLED39.json',final),'install_bytes_review':dump('INSTALL_BYTES_REVIEW.json',byte_review),'runtime_inventory':dump('INSTALLED_RUNTIME34.json',runtime_doc),'archive':{'path':str(ARCHIVE),'sha256':archive_sha}}
print(json.dumps(descriptors))
