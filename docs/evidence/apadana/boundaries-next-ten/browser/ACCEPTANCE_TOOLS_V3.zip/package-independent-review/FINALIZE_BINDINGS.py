"""Static source-template/data reconstruction and npm evidence binding only."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

R=Path('/tmp/pali-next-ten-boundaries-nov26')
E=Path('/tmp/pali-next-ten-evidence-nov26')
O=E/'package-independent-review'
APP='6ab4a322108aec740c330e4afd974ee4da808886'
def read(p):return Path(p).read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(b):return {'bytes':len(b),'sha256':sha(b)}
def j(p):return json.loads(read(p))
def compact(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def desc(p):return {'path':str(p),'sha256':sha(read(p))}
def dump(name,value):
    p=O/name
    with p.open('x',encoding='utf8') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return desc(p)
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='',GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GIT_TERMINAL_PROMPT='0')
def blob(name):
    return subprocess.run(['git','--no-pager','show',APP+':'+name],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,check=True).stdout
sources={}
def source(name):
    if name not in sources:
        p=R/name
        assert not p.is_symlink()
        raw=read(p)
        assert raw==blob(name),name
        sources[name]=raw
    return sources[name].decode()

installbytes=j(O/'INSTALL_BYTES_REVIEW.json')
final=j(O/'FINAL_COMMIT_ARCHIVE_INSTALLED39.json')
assert installbytes['candidate_commit']==final['commit']==APP
assert installbytes['members']==final['members'] and installbytes['archive_sha256']==final['archive_sha256']
rootpath=E/'package/ROOT_EXECUTION_RECEIPT.json'
root=j(rootpath)
debugpath=E/'package/NPM_OFFLINE_INSTALL_DEBUG.log'
debug=read(debugpath)
assert sha(debug)==root['npm_debug_log_sha256']=='8109db4b9df28be4115c78f00ce1a5c846b3a3aa585e69c9d6f966e4be69783d'
assert root['exit_code']==0 and root['offline_mode_requested'] is True and root['lifecycle_scripts_disabled'] is True
argv=next(line for line in debug.decode().splitlines() if ' verbose argv ' in line)
for option in ('"--offline"','"--ignore-scripts"','"--no-audit"','"--no-fund"'):
    assert option in argv,option
assert str(E/'installed') in argv and str(E/'package/pali-canon-mcp-2.1.0.tgz') in argv
assert re.search(rb'^\d+ verbose exit 0$',debug,re.M)
assert not re.search(rb'^\d+ http fetch\b',debug,re.M)
assert not re.search(rb'^\d+ (?:info|silly) run\b',debug,re.M)
assert not re.search(rb'https?://',debug)
assert root['network_packet_capture_performed'] is False and root['npm_debug_http_fetch_lines']==[]
installed=j(E/'installed/package.json')
assert installed=={'dependencies':{'pali-canon-mcp':'file:../package/pali-canon-mcp-2.1.0.tgz'}}
install={
 'schema':'independent-next-ten-genuine-offline-install39-v1','status':'PASS',
 'candidate_commit':APP,'installed':installbytes['installed'],'archive':installbytes['archive'],'archive_sha256':installbytes['archive_sha256'],
 'members':installbytes['members'],'all39_archive_checkout_install_bytes_exact':True,
 'offline_npm_install':True,'npm_scripts_executed':False,'registry_downloads':0,'observed_http_fetches':0,
 'process_evidence':{'root_execution_receipt':desc(rootpath),'npm_debug_log':desc(debugpath),'install_stdout_log':desc(E/'package/install.log'),'exact_install_command':root['install_command'],'npm_exit':0,'npm_log_scope':'Zero npm HTTP fetch lines and no remote URL or lifecycle-run lines; offline and ignore-scripts options present. This is npm debug evidence, not packet capture.','network_packet_capture_performed':False},
 'byte_evidence':desc(O/'INSTALL_BYTES_REVIEW.json'),'application_commit_binding':desc(O/'FINAL_COMMIT_ARCHIVE_INSTALLED39.json'),
 'behavioral_harness_approval':False,'release_or_push_approval':False,
 'scope_limits':['Actual root-owned fresh offline installation, verified by command/debug evidence and independent all39 exact byte comparison.', 'No app/server/browser/test/install command executed by this reviewer.', 'Commit names the exact application component; a later final test-only commit needs its own exact-Git39 rebind before claiming final-commit acceptance.']}

# Parse the finite JSON object literals in source modules, preserving order.
def object_and_spreads(name,constant):
    text=source(name)
    match=re.search(r'export const '+re.escape(constant)+r' = (?:(?:deepFreeze|freeze|Object\.freeze)\()?\{([\s\S]*?)\n\}\)?;',text)
    assert match,(name,constant)
    body=match.group(1)
    spread=re.findall(r'^  \.\.\.([A-Z0-9_]+),?$',body,re.M)
    body=re.sub(r'^  \.\.\.[A-Z0-9_]+,?\n?', '',body,flags=re.M).rstrip()
    if body.endswith(','):body=body[:-1]
    return json.loads('{'+body+'\n}'),spread
theri,spreads=object_and_spreads('src/apadana-profiles.mjs','THERI_APADANA_PROFILES')
assert not spreads
thera,spreads=object_and_spreads('src/apadana-thera-profiles.mjs','THERA_APADANA_PROFILES')
expected_spreads=['THERA_261_280_PROFILES','THERA_281_285_PROFILES','THERA_287_288_PROFILES','THERA_292_299_PROFILES','THERA_301_310_PROFILES','THERA_312_319_PROFILES','THERA_321_329_PROFILES','THERA_331_334_PROFILES']
assert spreads==expected_spreads
for constant in spreads:
    cohort=constant.removeprefix('THERA_').removesuffix('_PROFILES').replace('_','-')
    extra,subspreads=object_and_spreads('src/apadana-thera'+cohort+'-profiles.mjs',constant)
    assert not subspreads and not set(thera)&set(extra)
    thera.update(extra)
profiles=dict(theri)
assert not set(profiles)&set(thera)
profiles.update(thera)
assert len(profiles)==343
profiletext=source('src/apadana-profiles.mjs')
assert re.search(r'export const APADANA_PROFILES = deepFreeze\(\{\s*\.\.\.THERI_APADANA_PROFILES,\s*\.\.\.THERA_APADANA_PROFILES\s*\}\);',profiletext)
authoritypath=Path('/tmp/pali-four-english-evidence-nov26/ACTUAL343_PROFILE_OBSERVATION.json')
assert sha(read(authoritypath))=='f8bc0cfdcb97ed77e48076626754303a349041cc2aaa8d566853bc524213d664'
authority=j(authoritypath)
assert list(profiles)==authority['profile_ids']
for uid,p in profiles.items():
    assert sha(compact(p).encode())==authority['profile_object_sha256'][uid],uid

widget=source('src/chatgpt-widget.mjs')
assert widget.count('export const WIDGET_HTML = `')==1
template=widget.split('export const WIDGET_HTML = `',1)[1]
assert template.endswith('`;\n')
template=template[:-3]
expressions=re.findall(r'\$\{([^}]+)\}',template)
assert set(expressions)=={'JSON.stringify(SOURCE_NOTES_PROFILE)','SOURCE_NOTES_POLICY_SOURCE','WIDGET_HASH_SOURCE','WIDGET_VERSION','WIDGET_TOOL','NAVIGATION_TIMEOUT_MS','APADANA_BASE','JSON.stringify(WIDGET_APADANA)','APADANA_COMMIT','APADANA_LICENSE','APADANA_LICENSE_URL','APADANA_TRANSLATOR','JSON.stringify(PINNED_NEW_PARATEXT_IDS)','JSON.stringify(APADANA_PINS)','JSON.stringify(SCRIPT_CHOICES)','JSON.stringify(REPAIRED_CANONICAL_LOCATORS)'}
assert re.findall(r'\\.',template)==['\\\\','\\\\']
# Cook ONLY source template escape pairs before inserting untouched function/JSON strings.
template=template.replace('\\\\','\\')
def literal(text,name):
    match=re.search(r'(?:export )?const '+re.escape(name)+r' = ([^;\n]+);',text)
    assert match,name
    return ast.literal_eval(match.group(1))
pins=literal(widget,'APADANA_PINS')
paratext=literal(widget,'PINNED_NEW_PARATEXT_IDS')
def js_truthy(v):
    return isinstance(v,(list,dict)) or bool(v)
widgetprofiles={}
for uid,p in profiles.items():
    assert p['source']=='apadana'
    path=p['path'].removeprefix('/text/').removesuffix('/')
    selected={'translation_id':'ap:'+path,'url':p['url'],'fetched_url':p['raw_url'],'note_count':p['note_count'],'mapping_notes':p['mapping_notes']}
    for key in ('publisher_preface','collection_summary','chapter_summary','publisher_divisions','editorial_gap','note_numbers'):
        if js_truthy(p.get(key)):selected[key]=p[key]
    for key in pins:selected[key]=p[key]
    widgetprofiles[uid]=selected
canon=source('src/canon.mjs')
assert "if (t.source === 'apadana') return `ap:${t.path.replace(/^\\/text\\/|\\/$/g, '')}`;" in canon
notes,spread=object_and_spreads('src/source-notes-profiles.mjs','SOURCE_NOTES_PROFILE')
assert not spread
def function_source(name,constant):
    text=source(name)
    marker='export function '+constant+'('
    assert text.count(marker)==1
    function=text[text.index(marker):].removeprefix('export ').rstrip()
    assert function.endswith('\n}')
    return function
hash_source=function_source('web/content-sha256.mjs','contentSha256')
policy_source=function_source('web/source-notes-policy.mjs','createSourceNotesPolicy')
registrytext=source('src/locator-policy.mjs')
commit=literal(registrytext,'APADANA_PAIR_SOURCE_COMMIT')
revisions={family:commit+'-'+literal(registrytext,'APADANA_'+family+'_INDEX_REVISION') for family in ('PAIR','FOUR','SIX','TEN')}
block=re.search(r'export const REPAIRED_CANONICAL_LOCATORS = Object.freeze\(\{([\s\S]*?)\}\);',registrytext).group(1)
registry={uid:revisions[family] for uid,family in re.findall(r"'(tha-ap\d+)': APADANA_(PAIR|FOUR|SIX|TEN)_LOCATOR_REVISION",block)}
assert len(registry)==22
scripts=literal(source('src/script.mjs'),'SCRIPTS')
values={'JSON.stringify(SOURCE_NOTES_PROFILE)':compact(notes),'SOURCE_NOTES_POLICY_SOURCE':policy_source,'WIDGET_HASH_SOURCE':hash_source,'WIDGET_VERSION':literal(widget,'WIDGET_VERSION'),'WIDGET_TOOL':literal(widget,'WIDGET_TOOL'),'NAVIGATION_TIMEOUT_MS':str(literal(widget,'NAVIGATION_TIMEOUT_MS')),'JSON.stringify(WIDGET_APADANA)':compact(widgetprofiles),'JSON.stringify(PINNED_NEW_PARATEXT_IDS)':compact(paratext),'JSON.stringify(APADANA_PINS)':compact(pins),'JSON.stringify(SCRIPT_CHOICES)':compact(scripts),'JSON.stringify(REPAIRED_CANONICAL_LOCATORS)':compact(registry)}
for name in ('APADANA_BASE','APADANA_COMMIT','APADANA_LICENSE','APADANA_LICENSE_URL','APADANA_TRANSLATOR'):
    values[name]=literal(profiletext,name)
result=re.sub(r'\$\{([^}]+)\}',lambda m:values[m.group(1)],template).encode('utf-8')
roothtmlpath=E/'package/SOURCE_WIDGET_HTML.html'
assert result==read(roothtmlpath),'Source-only finite template reconstruction differs from root source-only export'
assert len(result)==664059 and values['WIDGET_VERSION']=='v44'
htmlpath=O/'SOURCE_WIDGET_HTML.html'
with htmlpath.open('xb') as f:f.write(result)
widgetreview={
 'schema':'independent-next-ten-source-widget-html-review-v1','status':'PASS_SOURCE_ONLY_WHOLE_HTML_RECONSTRUCTION',
 'candidate_commit':APP,'source_module':{'path':str(R/'src/chatgpt-widget.mjs'),**rec(sources['src/chatgpt-widget.mjs'])},
 'expected_source_widget_html':{**desc(htmlpath),'bytes':len(result)},'root_source_export':{**desc(roothtmlpath),'bytes':len(result)},
 'widget_version':'v44','widget_uris':['ui://pali-canon/reader-v44.html','ui://pali-canon/reader-v44.skybridge.html'],
 'source_dependencies':{name:rec(raw) for name,raw in sorted(sources.items())},
 'all_source_dependency_bytes_equal_exact_application_commit':True,'all343_source_profile_full_objects_match_pinned_independent_authority':True,
 'profile_authority':desc(authoritypath),'source_template_interpolation_expressions':expressions,
 'method':'Stdlib-only parsing of finite JSON/source literals, exact function source strings, reviewed translationId AP branch, exact22 registry and known19 interpolation occurrences; cook only two template backslash pairs before interpolation. Entire independently reconstructed HTML equals root separately imported source export. No JavaScript app/source module imported or executed by this reviewer.',
 'root_export_evidence':desc(rootpath),'installed_or_http_html_used_as_expectation':False,'html_output_byte_exact':True,
 'behavioral_harness_approval':False,'release_or_push_approval':False,
 'scope_limits':['Metadata/template/source byte review only; neither installed HTTP resources nor widget JavaScript was executed or compared by this reviewer.', 'Root source export used source module WIDGET_HTML after global fetch denial; this is not an installed or HTTP resource golden.', 'Only explicit source/metadata/package paths were read by reviewer; no provider requests, private user profiles or personal drafts were accessed.', 'Actual installed resources/read bodies must still match this full HTML at browser acceptance.']}
descriptors={'install_receipt':dump('INSTALL_RECEIPT.json',install),'widget_source_review':dump('WIDGET_SOURCE_REVIEW.json',widgetreview),'expected_source_widget_html':desc(htmlpath),'final_commit_binding':desc(O/'FINAL_COMMIT_ARCHIVE_INSTALLED39.json'),'runtime_inventory':desc(E/'runtime-inventory/INDEPENDENT_NEXT_TEN_RUNTIME_INVENTORY.json'),'runtime_review':desc(E/'runtime-review/INDEPENDENT_NEXT_TEN_RUNTIME_REVIEW.json'),'archive':{'path':final['archive'],'sha256':final['archive_sha256']},'widget_version':'v44','widget_uris':widgetreview['widget_uris'],'behavioral_harness_approval':False,'release_or_push_approval':False,'application_component_commit':APP,'final_test_commit_binding':'Not claimed; rebind later exact final commit if different from application component.'}
descriptor=dump('BINDING_DESCRIPTORS.json',descriptors)
print(json.dumps({'descriptors':descriptor,**descriptors}))
