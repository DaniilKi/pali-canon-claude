"""Fresh final-SHA package binding. Read-only Git/archive/files/JSON/TAP only."""
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import re
import subprocess
import tarfile

R=Path('/tmp/pali-next-ten-boundaries-nov26')
E=Path('/tmp/pali-next-ten-evidence-nov26')
O=E/'package-independent-review'
APP='6ab4a322108aec740c330e4afd974ee4da808886'
FINAL='2b4c9b1c7a1606dab890816657623ac26dcb4103'
ARCHIVE_SHA='74d9384ca1fe34d89f57ab914ddc3062e87db3034796c48843dde4cfd69e5ef5'
INV_SHA='ea2b5cfb7c7a6c9216e2f33a5d1950c128b1ef50cb6c32cf929cf555b942408f'
REVIEW_SHA='b3197bdcc429700dee09446abd01ff08c6009d4fcaedc3f2f542429c4f497f55'
HTML_SHA='240f9f42a00a2f9d2c8b89ab2d5271eeac686b0d8c4d45b02bb965f6d624c634'
def read(p):return Path(p).read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(b):return {'bytes':len(b),'sha256':sha(b)}
def desc(p):return {'path':str(p),'sha256':sha(read(p))}
def j(p):return json.loads(read(p))
def dump(name,value):
    p=O/name
    with p.open('x',encoding='utf8') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return desc(p)
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='',GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GIT_TERMINAL_PROMPT='0')
def git(*args):
    return subprocess.run(['git','--no-pager',*args],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,check=True).stdout
def blob(commit,path):return git('show',commit+':'+path)
assert git('rev-parse','HEAD').decode().strip()==FINAL
git('merge-base','--is-ancestor',APP,FINAL)
oldbinding=j(O/'FINAL_COMMIT_ARCHIVE_INSTALLED39.json')
install=j(O/'INSTALL_RECEIPT.json')
assert oldbinding['commit']==install['candidate_commit']==APP
assert oldbinding['members']==install['members'] and len(oldbinding['members'])==39
archive=Path(oldbinding['archive'])
assert sha(read(archive))==ARCHIVE_SHA==oldbinding['archive_sha256']==install['archive_sha256']
installed=Path(install['installed'])
members={}
with tarfile.open(archive,'r:gz') as tar:
    entries=tar.getmembers()
    assert len(entries)==39
    for entry in entries:
        assert entry.isfile() and entry.name.startswith('package/')
        name=entry.name.removeprefix('package/')
        pp=PurePosixPath(name)
        assert pp.as_posix()==name and not pp.is_absolute() and all(x not in ('','.','..') for x in pp.parts)
        assert name not in members and name in oldbinding['members']
        data=tar.extractfile(entry).read()
        assert not (installed/name).is_symlink() and not (R/name).is_symlink()
        assert data==read(installed/name)==read(R/name)==blob(FINAL,name)==blob(APP,name),name
        members[name]=rec(data)
members=dict(sorted(members.items()))
assert members==oldbinding['members']
allinstalled=[]
for p in installed.rglob('*'):
    assert not p.is_symlink(),str(p)
    if p.is_file():allinstalled.append(p.relative_to(installed).as_posix())
    else:assert p.is_dir()
assert sorted(allinstalled)==list(members)
runtime={name.removeprefix('server/'):row for name,row in members.items() if name.startswith('server/')}
assert len(runtime)==34
inventorypath=E/'runtime-inventory/INDEPENDENT_NEXT_TEN_RUNTIME_INVENTORY.json'
reviewpath=E/'runtime-review/INDEPENDENT_NEXT_TEN_RUNTIME_REVIEW.json'
assert sha(read(inventorypath))==INV_SHA and sha(read(reviewpath))==REVIEW_SHA
assert runtime==j(inventorypath)['files']==j(reviewpath)['files']
assert blob(FINAL,'docs/evidence/apadana/boundaries-next-ten/runtime/INDEPENDENT_NEXT_TEN_RUNTIME_INVENTORY.json')==read(inventorypath)
assert blob(FINAL,'docs/evidence/apadana/boundaries-next-ten/runtime/INDEPENDENT_NEXT_TEN_RUNTIME_REVIEW.json')==read(reviewpath)
widgetreview=j(O/'WIDGET_SOURCE_REVIEW.json')
htmlpath=O/'SOURCE_WIDGET_HTML.html'
assert len(read(htmlpath))==664059 and sha(read(htmlpath))==HTML_SHA
assert read(htmlpath)==read(E/'package/SOURCE_WIDGET_HTML.html')
dependencies={}
for name,expected in widgetreview['source_dependencies'].items():
    raw=read(R/name)
    assert rec(raw)==expected and raw==blob(FINAL,name)==blob(APP,name),name
    dependencies[name]=expected

diffraw=git('diff','--name-status',APP,FINAL)
changes=[]
script_helpers={'scripts/web_reader_approved_acceptance.py','scripts/web_reader_six_boundary_history.py','scripts/web_reader_next_ten_boundary_history.py'}
for line in diffraw.decode().splitlines():
    status,path=line.split('\t')
    assert status in ('A','M'),line
    if path.startswith('docs/'):
        category='documentation_and_frozen_validation_evidence'
    elif path.startswith('tests/'):
        category='tests_helpers_or_historical_test_fixtures'
    elif path in script_helpers:
        category='test_only_python_history_acceptance_helper'
    elif path=='.github/workflows/check.yml':
        category='CI_validation_wiring'
    else:
        raise AssertionError('Application or undeclared change since reviewed component: '+path)
    assert not path.startswith(('src/','web/','server/'))
    assert path not in ('package.json','package-lock.json','README.md','LICENSE','THIRD_PARTY.md','PRIVACY.md')
    changes.append({'status':status,'path':path,'classification':category,'final_record':rec(blob(FINAL,path))})
assert changes
workflow_before=blob(APP,'.github/workflows/check.yml').decode()
workflow_after=blob(FINAL,'.github/workflows/check.yml').decode()
# Independently closed whole-file inverse: add pinned book37, strict16-case gate, artifact.
assert workflow_after.count('            romn/s0510m2.mul.xml\n')==1
wf=workflow_after.replace('            romn/s0510m2.mul.xml\n','')
start=wf.index('      - name: Require next-ten original-source and saved-citation compatibility without skips\n')
end=wf.index('      - name: Validate independently reviewed Therā expansion and held-source refusals\n',start)
gate=wf[start:end]
assert 'timeout-minutes: 5' in gate
assert 'VRI_SOURCE_CHECKOUT: .fixtures/apadana-vri-pinned' in gate
assert '[["tests",16],["pass",16],["fail",0],["cancelled",0],["skipped",0],["todo",0]]' in gate
assert 'test -f "$VRI_SOURCE_CHECKOUT/romn/s0510m2.mul.xml"' in gate
wf=wf[:start]+wf[end:]
assert wf.count('            reviewed-next-ten.tap\n')==1
wf=wf.replace('            reviewed-next-ten.tap\n','')
assert wf==workflow_before
proof={'schema':'independent-final-next-ten-validation-only-delta-proof-v1','status':'PASS_FINITE_VALIDATION_ONLY_DIFF','application_component_commit':APP,'final_commit':FINAL,'component_is_ancestor':True,'changed_paths':changes,'changed_path_count':len(changes),'git_name_status_sha256':sha(diffraw),'source_web_server_all_package_notice_paths_unchanged':True,'all39_package_members_equal_between_component_and_final':True,'all_widget_source_dependencies_equal_between_component_and_final':True,'widget_source_dependencies':dependencies,'workflow_finite_inverse_restores_entire_component_bytes':True,'workflow_only_changes':['Add pinned original Book37 to existing sparse checkout','Add bounded next-ten16case no-skip/no-todo/no-cancellation TAP gate','Retain next-ten TAP artifact'],'old_required_checks_and_deadlines_preserved_by_whole_file_inverse':True,'review_method':'Local Git object, source/data/JSON/archive byte inspection only; no app/test/build/network/CI/Git mutation or tracked writes.','behavioral_harness_approval':False,'release_or_push_approval':False}
proofdescriptor=dump('PROOF_6AB_TO_2B4C_VALIDATION_ONLY.json',proof)

reports=[]
for name,expected in [('prior-six-source-input-repaired.tap',4),('approved-acceptance-repaired.tap',1),('source-history-final.tap',7),('reviewed-prior-six-final.tap',23)]:
    path=E/name
    raw=read(path)
    text=raw.decode()
    values={key:int(value) for key,value in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)}
    assert values=={'tests':expected,'pass':expected,'fail':0,'cancelled':0,'skipped':0,'todo':0},name
    assert not re.search(r'^not ok\b',text,re.M)
    duration=float(re.search(r'^# duration_ms ([0-9.]+)$',text,re.M).group(1))
    row={'file':name,'sha256':sha(raw),'tap_summary':values,'duration_ms':duration,'reviewed_existing_report_only_not_rerun':True}
    if name=='approved-acceptance-repaired.tap':
        wrapper=blob(FINAL,'tests/approved-acceptance.test.mjs')
        assert b'timeout:30000' in wrapper and b'assert.match(result.stderr,/Ran 33 tests/)' in wrapper
        assert duration<30000
        row.update(python_case_count_enforced_by_unchanged_wrapper=33,python_child_deadline_ms=30000)
    reports.append(row)
reportreview=dump('LOCAL_REPORTS_REVIEW_2B4C.json',{'schema':'independent-existing-local-tap-report-review-v1','candidate_commit':FINAL,'status':'PASS_FOUR_COMPLETED_REPORTS_ONLY','reports':reports,'full_check_and_browser_v3':'PENDING_AT_REVIEW; no passing claim','reviewer_test_execution':False,'behavioral_harness_approval':False,'release_or_push_approval':False})

binding={'schema':'independent-final-next-ten-git-archive-installed39-binding-v1','status':'PASS','commit':FINAL,'candidate_commit':FINAL,'application_component_commit':APP,'members':members,'archive':str(archive),'archive_sha256':ARCHIVE_SHA,'installed':str(installed),'all39_commit_archive_installed_exact':True,'all39_archive_checkout_install_bytes_exact':True,'runtime_files':runtime,'runtime_inventory':desc(inventorypath),'runtime_review':desc(reviewpath),'original_component_binding':desc(O/'FINAL_COMMIT_ARCHIVE_INSTALLED39.json'),'preserved_offline_install_receipt':desc(O/'INSTALL_RECEIPT.json'),'expected_source_widget_html':{**desc(htmlpath),'bytes':664059},'widget_source_review':desc(O/'WIDGET_SOURCE_REVIEW.json'),'source_html_static_dependency_binding_unchanged':True,'validation_only_delta_proof':proofdescriptor,'completed_local_reports_review':reportreview,'widget_version':'v44','widget_uris':widgetreview['widget_uris'],'old_component_receipts_preserved':True,'behavioral_harness_approval':False,'release_or_push_approval':False,'pending':['Running npm run check-final outcome','Actual installed browser V3 result and independent reconciliation','Exact final commit GitHub CI required check outcomes and subsequent authorization gate'],'method':'Fresh exact final Git39 versus application component Git39, preserved actual archive39, checkout39 and genuine installed39 bytes. Source-only HTML remains bound to exact unchanged final source dependencies. No app/test/build/network/CI/Git mutation/tracked edit.'}
assert git('rev-parse','HEAD').decode().strip()==FINAL
bindingdesc=dump('FINAL_2B4C_BINDING.json',binding)
print(json.dumps({'binding':bindingdesc,'validation_only_delta_proof':proofdescriptor,'local_reports_review':reportreview,'package39':39,'runtime34':34,'component_to_final_changed_paths':len(changes),'browser_v3_and_CI':'PENDING_NOT_CLAIMED'}))
