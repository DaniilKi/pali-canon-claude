"""Metadata-only compatibility/binding and raw XML edge proof; no app execution."""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET,ast
P=Path('/tmp/pali-next-ten-evidence-nov26/acceptance-plan');O=Path(__file__).resolve().parent;D=Path('/tmp/pali-next-ten-evidence-nov26/source-oracle');H=lambda b:hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest();J=lambda x:H(json.dumps(x,ensure_ascii=False,separators=(',',':')))
a=json.loads((D/'FUTURE_ORACLE.json').read_bytes());r=json.loads((O/'READER_ORACLES.json').read_bytes());x=json.loads((O/'CROSSWALK144.json').read_bytes());receipt=json.loads((O/'CONVERSION_RECEIPT.json').read_bytes());assert r['schema']=='source-first-next10-boundary-reader-oracles-v1' and r['index_revision']=='apadana-thera-next10-v1' and sum(len(u['old_segments']) for u in r['units'])==sum(len(u['future_segments']) for u in r['units'])==144
# Check native fixture/save choices using metadata only; execute no harness function.
choices=[]
for u in r['units']:
 old=u['old_segments'];new=u['future_segments'];assert 4<=len(new)<=40
 reserved=next(s['ref'] for s in new if s['type']=='verse' and s['ref']!=old[0]['ref']);candidates=[s for s in old[1:] if s['ref']!=reserved];assert candidates
 byref={s['ref']:s for s in new};witness=next((s for s in candidates if s['ref'] not in byref or s['text_sha256']!=byref[s['ref']]['text_sha256']),candidates[-1]);assert old[0]['ref']!=witness['ref'];assert any(s['type']=='verse' and s['ref'] not in (old[0]['ref'],witness['ref']) for s in new)
 choices.append({'id':u['id'],'pinned_old_ref':old[0]['ref'],'unversioned_old_ref':witness['ref'],'available_current_verse':reserved})
# Independently verify printed inline markers, distinguishing start-carry PTS290 from inline PTS291.
pin=a['original_sources']['36'];raw=Path(pin['path']).read_bytes();assert H(raw)==pin['sha256'];nodes=[e for e in ET.fromstring(raw).iter() if e.tag in ('p','head','trailer')];node=nodes[10789];out=[''];events=[]
def walk(n):
 out[0]+=n.text or ''
 for c in n:
  if c.tag=='pb':
   t=re.sub(r'\s+',' ',out[0]).strip();events.append({'edition':c.get('ed'),'page':'.'.join(str(int(v)) for v in c.get('n').split('.')),'visible_offset':len(t),'visible_prefix_sha256':H(t)})
  elif c.tag!='note' and not(c.tag=='hi' and c.get('rend') in ('paranum','dot')):walk(c)
  out[0]+=c.tail or ''
walk(node);assert events==a['notes_and_pages']['PTS10788_inline'];assert next(e for e in events if e['edition']=='P')['page']=='1.291'
new427=next(u for u in r['units'] if u['id']=='tha-ap427');note214=next(s for s in new427['future_segments'] if s['source_blocks'][0]<=214<s['source_blocks'][1]);assert note214['variant_reading_count']==1
unlabelled=next(s for u in r['units'] if u['id']=='tha-ap429' for s in u['future_segments'] if s['source_blocks']==[292,293]);assert unlabelled['type']=='verse' and unlabelled['vri_paragraph'] is None
edge={'status':'VERIFIED_RAW_SOURCE_METADATA_ONLY','PTS10788_inline':events,'tha_ap375_start_PTS_annotation':next(z['after']['pts'] for z in a['records'] if z['id']=='tha-ap375'),'correction_to_prior_design':'Original PLAN repeated shorthand inlinePTS290. Actual pinned XML prints PTS1.291 after20visiblecharacters atblock10788; PTS290 is carried unit-start annotation. EarlierPLAN/designseal preserved; source expectations and convertedreader never changed.','note214':note214,'unlabelled292':unlabelled,'native_fixture_choices':choices,'20_old_records_and10_unoccupied_current_verses_verified':True}
(O/'EDGE_AND_FIXTURE_PROOF.json').write_text(json.dumps(edge,ensure_ascii=False,indent=2)+'\n')
# Preserve the original blocked template and harness. Bind only actual source-derived descriptors in a new contract.
c=json.loads((P/'CONTRACT_TEMPLATE.json').read_bytes());c['execution_status']='BLOCKED_PENDING_PEER_REVIEW_AND_FUTURE_RUNTIME_BINDINGS';c['oracles']={'path':str(O/'READER_ORACLES.json'),'sha256':H((O/'READER_ORACLES.json').read_bytes())};c['crosswalk']={'path':str(O/'CROSSWALK144.json'),'sha256':H((O/'CROSSWALK144.json').read_bytes())};c['source_evidence']={n:{'path':str(D/n),'sha256':H((D/n).read_bytes())} for n in ['FUTURE_ORACLE.json','POSITION_CROSSWALK144.json','ISOLATED_RENDER_POSITIONS.json','ORACLE_COMPLETION.json','FINAL_ORACLE_SEAL.json']};c['source_conversion']={n:{'path':str(O/n),'sha256':H((O/n).read_bytes())} for n in ['CONVERSION_RECEIPT.json','EDGE_AND_FIXTURE_PROOF.json']};c['required_authorities']['source_boundary_review']={'path':str(D/'ORACLE_COMPLETION.json'),'sha256':H((D/'ORACLE_COMPLETION.json').read_bytes())};c['required_authorities']['source_oracle_review']={'path':'PENDING_INDEPENDENT_CONVERSION_PEER_REVIEW','sha256':'PENDING_INDEPENDENT_CONVERSION_PEER_SHA256'}
c['pending_roles']=['Independent schema/model/harness review; READY is not assigned by producer','Actual package/runtime/sourceHTML/widgetversion/finalGit39/sourcepreservation receipts for future application; no old inventory reuse'];assert c['future_canonical_logical_sha256']==r['future_canon_sha256'];assert c['control_ids']==[v['arguments']['uid'] for v in r['unaffected_controls']]
for name,sha in c['harness_closure'].items():assert H((P/'proposal'/name).read_bytes())==sha
(O/'CONTRACT_SOURCE_BOUND.json').write_text(json.dumps(c,indent=2)+'\n')
# Verify proposal source syntax only; no imports or harness execution.
ast.parse((P/'proposal/check-boundary-reader.py').read_bytes());ast.parse((O/'convert_source_metadata.py').read_bytes())
seal={'schema':'independent-next10-reader-adapter-proposal-seal-v1','status':'SOURCE_METADATA_CONVERTED_READY_FOR_NARROW_PEER_REVIEW_RUNTIME_HELD','files':{n:H((O/n).read_bytes()) for n in ['convert_source_metadata.py','finish_bindings.py','READER_ORACLES.json','CROSSWALK144.json','CONVERSION_RECEIPT.json','EDGE_AND_FIXTURE_PROOF.json','CONTRACT_SOURCE_BOUND.json']},'unchanged_harness_sha256':H((P/'proposal/check-boundary-reader.py').read_bytes()),'all_negative_clauses_and_sameobject_private_guards_unchanged':True,'only_metadata_conversions_and_isolated_source_model_executed':True,'app_test_browser_build_Git_network_execution':False}
(O/'ADAPTER_SEAL.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps({'seal_sha256':H((O/'ADAPTER_SEAL.json').read_bytes()),'contract_sha256':H((O/'CONTRACT_SOURCE_BOUND.json').read_bytes()),'edge_sha256':H((O/'EDGE_AND_FIXTURE_PROOF.json').read_bytes()),'harness_sha256':seal['unchanged_harness_sha256']},indent=2))
