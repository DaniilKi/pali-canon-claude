"""Pure metadata conversion and independent Python source model. No app imports.
Raw words/notes exist only in memory; output contains hashes, positions and metadata.
"""
from pathlib import Path
import collections,copy,gzip,hashlib,json,re,xml.etree.ElementTree as ET
D=Path('/tmp/pali-next-ten-evidence-nov26/source-oracle');O=Path(__file__).resolve().parent;FROZEN=Path('/tmp/pali-boundaries340-nov26')
H=lambda b:hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()
C=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':')).encode()
J=lambda x:H(C(x));VRI='2d134ff9ef60f70a1eb03c9370580228811a3070';REV='apadana-thera-next10-v1'
IDS=['tha-ap348','tha-ap349','tha-ap374','tha-ap375','tha-ap423','tha-ap424','tha-ap426','tha-ap427','tha-ap428','tha-ap429']
def read(name):return json.loads((D/name).read_bytes())
sealraw=(D/'FINAL_ORACLE_SEAL.json').read_bytes();assert H(sealraw)=='fb1e29730c4208ea866ab23cd1eb35d5c85d1658a33037933be756bfdef841d9'
seal=json.loads(sealraw)
for name,row in seal['files'].items():
 raw=(D/name).read_bytes();assert len(raw)==row['bytes'] and H(raw)==row['sha256']
a=read('FUTURE_ORACLE.json');x=read('POSITION_CROSSWALK144.json');obs=read('ISOLATED_RENDER_POSITIONS.json');completion=read('ORACLE_COMPLETION.json')
assert H((D/'FUTURE_ORACLE.json').read_bytes())=='78fd34efd9942bb363010123f4019cfa31df3b609fbd3736d2db7288c2036655'
assert H((D/'POSITION_CROSSWALK144.json').read_bytes())=='223bc745f40774b50f41df41073f1b7f8c67b8eb4067ef28556dd4bb22ac439f'
assert H((D/'ORACLE_COMPLETION.json').read_bytes())=='180d5f87e280ef773a5043d85b00c4f94fe89a02bbe3f040dde0658b7ae30648'
assert a['targets']==IDS and a['index_revision']==REV and a['locator_revision_length']==64
assert H((FROZEN/'src/canon.mjs').read_bytes())==obs['canon_source_sha256']=='b496860add5770a775023b28739c4821af459c96803af644a5ecd20fcc69883f'
assert H((FROZEN/'src/editions.mjs').read_bytes())==obs['editions_source_sha256']=='ab2306502a68171b474969ddd6c96d16e37891c4d451a6e78b8b17bcc505b68b'
# Read frozen dd7 JSON as data only, refuse a future/candidate canonical snapshot.
m=json.loads((FROZEN/'server/data/canon.json.gz.parts.json').read_bytes());ps=[]
for r in m['parts']:
 raw=(FROZEN/'server/data'/r['file']).read_bytes();assert len(raw)==r['size'] and H(raw)==r['sha256'];ps.append(raw)
packed=b''.join(ps);assert len(packed)==m['size'] and H(packed)==m['sha256'];cr=gzip.decompress(packed);assert H(cr)==a['old_canonical_logical_sha256']=='0f9eedc279fbf63a93b541c27aae2f6b6e799e7bb3e5805c4da13b1692b9db7b';canon=json.loads(cr);assert J(canon['books'])==a['preservation']['all61_books_sha256']
# Independently recover every retained original tuple from both raw XML books.
original={};physical={};sourceproof={}
collapse=lambda t:re.sub(r'\s+',' ',t).strip()
def visible(e):
 out=e.text or ''
 for child in e:
  if child.tag not in ('note','pb') and not(child.tag=='hi' and child.get('rend') in ('paranum','dot')):out+=visible(child)
  out+=child.tail or ''
 return out
for bi in (36,37):
 pin=a['original_sources'][str(bi)];raw=Path(pin['path']).read_bytes();assert len(raw)==pin['bytes'] and H(raw)==pin['sha256'];assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==pin['git_blob_sha1']
 nodes=[e for e in ET.fromstring(raw).iter() if e.tag in ('p','head','trailer')];rows=[];kept=[];omitted=[]
 for i,e in enumerate(nodes):
  text,n=collapse(visible(e)),e.get('n')
  if not text and not n:omitted.append(i);continue
  pages={}
  for pb in e.iter('pb'):pages.setdefault(pb.get('ed'),[]).append('.'.join(str(int(k)) for k in pb.get('n').split('.')))
  rows.append([e.get('rend') or ('centre' if e.tag=='trailer' else 'bodytext'),n,text,[collapse(''.join(v.itertext())) for v in e.iter('note')],pages]);kept.append(e)
 assert rows==canon['books'][bi]['blocks'] and J(rows)==pin['full_tuple_sha256'];assert len(rows)==pin['retained_tuples'] and omitted==pin['omitted_note_only_indices']
 original[bi]=rows;physical[bi]=kept;sourceproof[str(bi)]={**pin,'full_tuple_equality_independently_replayed':True}
# Plain Python model of frozen dd7 renderUnitSegments contract. No extracted app code executed.
HEAD={'subhead','title','chapter','book','nikaya','subsubhead'};VERSE={'gatha1','gatha2','gatha3','gathalast'};CENTRE=re.compile(r'(niṭṭhit[aāo]ṃ?|niṭṭhitā|samattaṃ|samattā)\.?$|^Namo tassa|uddānaṃ$',re.I)
ED={'T':('thai','Thai'),'M':('myanmar','Myanmar'),'V':('vri','VRI')};owners={}
for bi,b in enumerate(canon['books']):
 for row in b['blocks']:
  for ed in ED:
   for at in row[4].get(ed,[]):owners.setdefault((ed,b['collection'],at),set()).add(bi)
needs={(ed,col) for (ed,col,at),books in owners.items() if len(books)>1}
assert needs=={('V','an'),('V','sn')}
def label(bi,ed,at):
 b=canon['books'][bi];v,p=at.split('.');where=p if int(v)==0 else str(int(v))+'.'+p;scope={'ap':'Ap','mn':'MN'}[b['collection']];tail=' ('+b['title']+')' if (ed,b['collection']) in needs else '';return ED[ed][1]+' '+scope+' '+where+tail
def pts(col,at):
 v,p=map(int,at.split('.'));abbr={'ap':'Ap','mn':'M'}[col];return abbr+' '+(('i' if v==1 else 'ii' if v==2 else str(v))+' ' if v else '')+str(p)
def uniq(xs):return list(dict.fromkeys(xs))
def render(unit):
 bi=unit['book'];rows=canon['books'][bi]['blocks'];out=[];stanza=None;pending=[]
 def flush():
  nonlocal stanza
  if stanza is not None:out.append(stanza);stanza=None
 for index in range(unit['start'],unit['end']):
  rend,n,text,notes,pages=rows[index];eds=pending+[(ed,at) for ed in ED for at in pages.get(ed,[])];pending=[];pp=list(pages.get('P',[]))
  if rend=='hangnum':flush();stanza={'type':'verse','n':n,'text':'','notes':[],'pts':[],'eds':eds,'span':[index,index+1]};continue
  if rend in VERSE:
   if stanza is None:stanza={'type':'verse','n':n,'text':'','notes':[],'pts':[],'eds':[],'span':[index,index+1]}
   stanza['span'][1]=index+1;stanza['text']+=('\n' if stanza['text'] else '')+text;stanza['notes']+=notes;stanza['pts']+=pp;stanza['eds']+=eds
   if rend=='gathalast':flush()
  else:
   flush()
   if not text:pending=eds;continue
   out.append({'type':'heading' if rend in HEAD or rend=='centre' and CENTRE.search(text) else 'prose','n':n,'text':text,'notes':notes[:],'pts':pp,'eds':eds,'span':[index,index+1]})
 flush();result=[]
 for i,r in enumerate(out):
  result.append({'ref':unit['id']+'/'+str(i+1),'uid':unit['id'],'segment_index0':i,'offset':i,'type':r['type'],'vri_paragraph':r['n'],'source_blocks':r['span'],'text_sha256':H(r['text']),'text_utf16_length':len(r['text'].encode('utf-16-le'))//2,'source_note_sha256':[H(t) for t in r['notes']],'source_notes_sha256':J(r['notes']),'variant_reading_count':len(r['notes']),'raw_PTS_page_begins':uniq(r['pts']),'raw_edition_page_begins':{ed:uniq([at for e,at in r['eds'] if e==ed]) for ed in ED},'pts_page_begins':uniq([pts(unit['collection'],v) for v in r['pts']]),**{key+'_page_begins':uniq([label(bi,ed,at) for e,at in r['eds'] if e==ed]) for ed,(key,name) in ED.items()}})
 return result
# Convert isolated metadata with explicit aliases/defaults, then compare every semantic field to raw-source model.
allowed={'ref','type','source_blocks','vri_paragraph','text_sha256','text_utf16_length','notes_sha256','note_count','note_text_sha256','pts_page_begins','thai_page_begins','myanmar_page_begins','vri_page_begins'}
def converted(raw,uid,i,model):
 assert set(raw)<=allowed and raw['ref']==uid+'/'+str(i+1)
 alias={'ref':raw['ref'],'uid':uid,'segment_index0':i,'offset':i,'type':raw['type'],'vri_paragraph':raw.get('vri_paragraph'),'source_blocks':raw['source_blocks'],'text_sha256':raw['text_sha256'],'text_utf16_length':raw['text_utf16_length'],'source_note_sha256':raw.get('note_text_sha256',[]),'source_notes_sha256':raw['notes_sha256'],'variant_reading_count':raw['note_count'],**{k:raw.get(k,[]) for k in ('pts_page_begins','thai_page_begins','myanmar_page_begins','vri_page_begins')}}
 for k,v in alias.items():assert C(model[k])==C(v),(uid,i,k)
 return model
rows={r['id']:r for r in a['records']};units=[];oldflat=[];newflat=[]
for uid,o,n in zip(IDS,obs['old'],obs['proposed'],strict=True):
 assert o['id']==n['id']==uid;record=rows[uid];assert J(record['before'])==record['before_object_sha256'] and J(record['after'])==record['after_object_sha256']
 oldmodel=render(record['before']);newmodel=render(record['after']);assert len(o['segments'])==len(oldmodel) and len(n['segments'])==len(newmodel)
 oldseg=[converted(v,uid,i,oldmodel[i]) for i,v in enumerate(o['segments'])];newseg=[converted(v,uid,i,newmodel[i]) for i,v in enumerate(n['segments'])]
 units.append({'id':uid,'before_unit':record['before'],'after_unit':record['after'],'old_segments':oldseg,'future_segments':newseg});oldflat+=oldseg;newflat+=newseg
assert len(oldflat)==len(newflat)==144 and sum(s['variant_reading_count'] for s in oldflat)==sum(s['variant_reading_count'] for s in newflat)==17
oldby={s['ref']:s for s in oldflat};newby={s['ref']:s for s in newflat};assert len(oldby)==len(newby)==144
categories=collections.Counter();cross=[];moved=0
for raw in x['records']:
 old=oldby[raw['old']['ref']];dest=newby[raw['exact_source_new']['ref']];same=newby.get(old['ref']);bi=rows[old['uid']]['before']['book'];dbi=rows[dest['uid']]['after']['book'];assert bi==dbi and old['source_blocks']==dest['source_blocks']
 for k in ('type','vri_paragraph','text_sha256','text_utf16_length','source_note_sha256','source_notes_sha256','variant_reading_count','raw_PTS_page_begins','raw_edition_page_begins','pts_page_begins','thai_page_begins','myanmar_page_begins','vri_page_begins'):assert old[k]==dest[k]
 for prior,con in [(raw['old'],old),(raw['exact_source_new'],dest)]+([(raw['same_numeric_ref_new'],same)] if same else []):
  keys={'notes_sha256':'source_notes_sha256','note_count':'variant_reading_count','note_text_sha256':'source_note_sha256'}
  for k,v in prior.items():assert C(con[keys.get(k,k)])==C(v),(old['ref'],k)
 assert (raw['same_numeric_ref_new'] is None)==(same is None)
 cat='OLD_REF_ABSENT' if same is None else 'SAME_REF_SAME_SOURCE_NOT_MIGRATION_AUTHORITY' if same['source_blocks']==old['source_blocks'] else 'SAME_REF_DIFFERENT_SOURCE';assert cat==raw['classification'];categories[cat]+=1;moved+=old['uid']!=dest['uid']
 cross.append({'old':old,'source_identical_future_owner':dest,'same_numeric_ref_future':same,'category':cat,'require_new_pin_for_old_position':True,'automatic_private_data_migration_authorized':False})
assert dict(categories)==x['classification_counts'] and moved==10
# Whole raw-book references are derived from full source books, never XML block offsets-as-API-offsets.
books={};anchors=[];focuses={36:[10350,10367,10371,10763,10786,10788,10790],37:[0,51,55,212,214,216,273,277,292]}
for bi in (36,37):
 book=canon['books'][bi];bid=book['file'].replace('.mul.xml','');allrows=render({'id':'vri-book:'+bid,'book':bi,'start':0,'end':len(book['blocks']),'collection':book['collection']});books[str(bi)]={'book':bid,'segments':len(allrows),'whole_metadata_sha256':J(allrows)}
 if bi==36:assert len(allrows)==6018 and J(allrows)=='a41a77f5e8c62d99d217a8bca862c4b9b152edebe190cd5af3c8a781b0b2bbc9'
 for focus in focuses[bi]:
  matches=[i for i,r in enumerate(allrows) if r['source_blocks'][0]<=focus<r['source_blocks'][1]];assert len(matches)==1,(bi,focus)
  index=matches[0];offset=max(0,index-1);page=allrows[offset:offset+3];anchors.append({'source_book_index':bi,'source_block_focus':focus,'focus_segment_offset':index,'focus_segment_ref':allrows[index]['ref'],'arguments':{'book':bid,'offset':offset,'limit':3,'variants':'none'},'segments':page})
# Frozen prior/ordinary controls remain source-book data, not actual candidate tool output.
control_ids=['tha-ap107','tha-ap108','tha-ap333','tha-ap334','tha-ap335','tha-ap336','tha-ap340','tha-ap341','tha-ap343','tha-ap344','tha-ap346','tha-ap347','mn10','tha-ap350','tha-ap376','tha-ap425','tha-ap430'];byid={u['id']:u for u in canon['units']};controls=[]
for uid in control_ids:
 u=byid[uid];assert uid not in IDS;segs=render(u)[:1];controls.append({'arguments':{'uid':uid,'limit':1},'locator_revision':VRI+'-'+u['index_revision'] if 'index_revision'in u else None,'record_sha256':J(u),'segments':segs,'source_basis':'FROZEN_DD7_METADATA_AND_ORIGINAL_SOURCE_BOOK_TUPLES' if u['book']in (36,37) else 'FROZEN_DD7_UNCHANGED_CONTROL'})
reader={'schema':'source-first-next10-boundary-reader-oracles-v1','candidate_output_used_as_expectation':False,'origin':'Converted sealed independent144metadata, independently checked against rawXML/frozenDD7data with isolated Python source model; no app code imported or executed.','old_canon_sha256':a['old_canonical_logical_sha256'],'future_canon_sha256':a['future_canonical_logical_sha256'],'index_revision':REV,'units':units,'source_book_pages':anchors,'source_book_totals':books,'unaffected_controls':controls,'unchanged_apadana_manifest_sha256':a['preservation']['343_manifest_sha256'],'all61_book_hash':a['preservation']['all61_books_sha256'],'other8534_unit_hash':a['preservation']['full_other8534_records_sha256'],'metadata_only_no_words_emitted':True}
converted_cross={'schema':'source-first-next10-144-crosswalk-adapter-v1','source_input_sha256':H((D/'POSITION_CROSSWALK144.json').read_bytes()),'old_segments':144,'future_segments':144,'same_numeric_ref_different_source':69,'old_refs_absent_in_future_owner':10,'same_numeric_ref_same_source':65,'cross_owner_moves':10,'raw_source_note_count':17,'records':cross,'private_migration_authorized':False}
report={'schema':'independent-next10-reader-schema-conversion-receipt-v1','status':'GO_CONVERTED_METADATA_FOR_REVIEW_NOT_RUNTIME_ACTIVATION','source_final_seal_sha256':H(sealraw),'source_input_hashes':{n:H((D/n).read_bytes()) for n in ('FUTURE_ORACLE.json','POSITION_CROSSWALK144.json','ISOLATED_RENDER_POSITIONS.json','ORACLE_COMPLETION.json')},'all144_old_and144_future_field_values_crosschecked_raw_source_model':True,'categories':dict(categories),'source_notes_old_future':[17,17],'raw_sources':sourceproof,'frozen_canon_sha256':H(cr),'static_renderer_contracts':{'canon.mjs':obs['canon_source_sha256'],'editions.mjs':obs['editions_source_sha256'],'source-books.mjs':H((FROZEN/'src/source-books.mjs').read_bytes())},'model':'New standalone Python implementation of statically read grouping/notes/page-label contract; no extracted SUT code executed and no candidate code/output used.','sourcebook_anchors':len(anchors),'whole_sourcebook_metadata':books,'prior_controls':len(controls),'no_source_words_or_notes_written':True,'app_test_browser_build_Git_network_execution':False,'remaining':['Independent conversion/model/code review','Actual new application/runtime/package/sourceHTML binding','Root-owned actual installed/browser and exactCI execution']}
for name,value in [('READER_ORACLES.json',reader),('CROSSWALK144.json',converted_cross),('CONVERSION_RECEIPT.json',report)]:
 path=O/name;assert not path.exists();path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'outputs':{n:H((O/n).read_bytes()) for n in ['READER_ORACLES.json','CROSSWALK144.json','CONVERSION_RECEIPT.json']},'anchor_pages':len(anchors),'wholebooks':books},indent=2))
